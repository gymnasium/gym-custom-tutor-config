function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6gSx4QXGFgQ":
        Script1();
        break;
  }
}

function Script1()
{
  window.print(); 
}

